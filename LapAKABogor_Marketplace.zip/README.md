# LapAKABogor Marketplace

Marketplace untuk produk UKM, IKM, dan inovasi mahasiswa Politeknik AKA Bogor.

## Fitur:
- Checkout via WhatsApp
- Pengambilan atau pengantaran
- Kategori produk
- Dukungan metode pembayaran QRIS dan Cash
